 	<head>
 	    <meta charset="UTF-8">
 	    <title>Halaman Admin</title>
 	    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 	    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
 	    <!-- CSRF Token -->
 	    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

 	    <!-- VENDOR CSS -->
 	    <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
 	    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
 	    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/linearicons/style.css')); ?>">

 	    <!-- MAIN CSS -->
 	    <link rel="stylesheet" href="<?php echo e(url('assets/css/main.css')); ?>">
 	    <!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
 	    <link rel="stylesheet" href="<?php echo e(url('assets/css/demo.css')); ?>">
 	    <!-- GOOGLE FONTS -->
 	    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">

		<link href="<?php echo e(asset('css/waves.css')); ?>">

		<!-- Animation Css -->
		<link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" />

		<!-- Sweetalert Css -->
		<link href="<?php echo e(asset('css/sweetalert.css')); ?>" rel="stylesheet" />

		<link href="<?php echo e(asset('css/datepicker.min.css')); ?>" rel="stylesheet" />

		<link href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>" rel="stylesheet" />

		

 	</head><?php /**PATH D:\laragon\www\project_SMK\resources\views/items/html_header.blade.php ENDPATH**/ ?>