<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">

<?php $__env->startSection('html_header'); ?>
<?php echo $__env->make('items.html_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldSection(); ?>

<body>
    <!-- Page Loader -->
    <div class="preloader" id="preloader" style=" position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        z-index: 100000;
        backface-visibility: hidden;
        background: #ffffff;">
            <div class="preloader_img" style="width: 200px;
        height: 200px;
        position: absolute;
        left: 48%;
        top: 48%;
        background-position: center;
        z-index: 999999">
        <img src="<?php echo e(asset('img/loader.gif')); ?>" style=" width: 50px;" alt="loading...">
    </div>
</div>
    <!-- #END# Page Loader -->
    <div id="wrapper">

        <?php echo $__env->make('items.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('items.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="main">
            <div class="main-content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('main-content'); ?>
                </div>
            </div>
        </div>
    </div> <!-- /.Wrapper -->
    <?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('items.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

</body>

</html><?php /**PATH D:\laragon\www\project_SMK\resources\views/admin.blade.php ENDPATH**/ ?>