<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/scripts/klorofil-common.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

<script>
    $(function(){
        $('#preloader').fadeOut('slow');

        

    })

    
</script>
<?php echo $__env->yieldPushContent('script'); ?><?php /**PATH D:\laragon\www\project_SMK\resources\views/items/scripts.blade.php ENDPATH**/ ?>