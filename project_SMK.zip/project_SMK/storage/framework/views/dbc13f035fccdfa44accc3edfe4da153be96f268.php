<!-- LEFT SIDEBAR menu samping -->
<div id="sidebar-nav" class="sidebar">
	<div class="sidebar-scroll">
		<nav>
			<ul class="nav">
				<li><a href="<?php echo e(route('adminhome')); ?>" class=""><i class="lnr lnr-home"></i> <span>Dashboard</span></a>
				</li>
				<li>
					<a href="#subPages" data-toggle="collapse" class="collapsed"><i class="lnr lnr-menu"></i> <span>Menu</span>
					<i class="icon-submenu lnr lnr-chevron-left"></i></a>
						<div id="subPages" class="collapse ">
							<ul class="nav">
								<li><a href="<?php echo e(route('dataMatpel')); ?>"><i class="lnr lnr-bookmark"></i> <span>Mata Pelajaran</span></a></li>
							
							</ul>
						</div>
				</li>

			</ul>
		</nav>
	</div>
</div>
<!-- END LEFT SIDEBAR --><?php /**PATH D:\laragon\www\project_SMK\resources\views/items/sidebar_admin.blade.php ENDPATH**/ ?>