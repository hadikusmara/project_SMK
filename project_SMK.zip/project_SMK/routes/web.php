<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'UserController@index')->name('userhome');
Route::prefix('admin')->group(function () {
    Route::get('/', 'AdminController@index')->name('adminhome');


   // Mata Pelajaran
   Route::get('/matpel3', 'MatpelController@index')->name('dataMatpel');
   Route::get('/dataMatpel', 'MatpelController@get')->name('daftarMatpel');
   Route::post('/simpanMatpel', 'MatpelController@save')->name('simpanDataMatpel');
   Route::get('/cariMatpel/{id}', 'MatpelController@getMatpel');//mencari data 
   Route::post('/editMatpel/{id}', 'MatpelController@update');
   Route::get('/hapusDataMatpel/{id}', 'MatpelController@delete');
   //cari data berdasarkan input dari form
//Route::get('/cariURLMatpel/{id}/{id1}/{id2}', 'MatpelController@getURLMatpel');
//Route::get('/cariURLMatpel/{id}/{id2}/{id3}', 'MatpelController@getURLMatpel');

});